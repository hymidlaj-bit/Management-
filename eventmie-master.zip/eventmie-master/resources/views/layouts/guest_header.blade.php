<li class="nav-item">
    <a class="nav-link" href="{{ route('eventmie.login') }}"><i class="fas fa-fingerprint"></i> @lang('eventmie::em.login')</a>
</li>
<li class="nav-item">
    <a class="nav-link" href="{{ route('eventmie.register_show') }}"><i class="fas fa-user-plus"></i> @lang('eventmie::em.register')</a>
</li>
